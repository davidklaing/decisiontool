from distutils.core import setup

setup(
    name='decisiontool',
    version='0.1decisiontool',
    packages=['decisiontool'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
